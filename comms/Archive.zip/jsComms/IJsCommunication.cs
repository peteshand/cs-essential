

using System;
using UnityEngine;
using p2p;

namespace jsComms
{
    public interface IJsCommunication
    {
        //Transform contextViewTransform { get; set; }
        void Init();
        void Send(string id, string message);
        void AddListener(string id, Action<string> callback);
        void Close();
    }
}