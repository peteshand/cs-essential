using System;
using System.Collections.Generic;
using System.Dynamic;
using Newtonsoft.Json;
using notifier;
using UnityEngine;
using static Trace;
using p2p;
using LitJson;
using comms;

namespace jsComms
{
	public class JsComms
	{
        internal static Dictionary<string, dynamic> Broadcasters { get => broadcasters; set => broadcasters = value; }
        internal static Dictionary<string, dynamic> Subscribers { get => subscribers; set => subscribers = value; }

        private static List<dynamic> broadcasters2 = new List<dynamic>();
        private static Dictionary<string, dynamic> broadcasters = new Dictionary<string, dynamic>();
        private static Dictionary<string, dynamic> subscribers = new Dictionary<string, dynamic>();
        static public IJsCommunication communication;

        static Transform contextViewTransform;

        public static void initialize(Transform contextViewTransform)
        {
            JsComms.contextViewTransform = contextViewTransform;
        }

        public static void install<T>() where T : Component {
            GameObject _communication = new GameObject ("JsComms");
			_communication.transform.parent = contextViewTransform;
			communication = (IJsCommunication)_communication.AddComponent<T> ();
            communication.Init();

            Send("initialize", true);
        }

        public static void addBroadcast<T>(Notifier<T> notifier, string id) {
            if (JsComms.communication == null) {
                trace("JsComms.install(...) needs to be called before you can add broadcasters");
                return;
            }
            broadcasters.Add(id, new Broadcaster<T>(notifier, id));
        }

        public static void addSubscriber<T>(Notifier<T> notifier, string id) {
            if (JsComms.communication == null) {
                trace("JsComms.install(...) needs to be called before you can add subscribers");
                return;
            }
            subscribers.Add(id, new Subscriber<T>(notifier, id));
        }

        public static void Send<T>(string id, T payload)
        {
            if (JsComms.communication == null) {
                trace("JsComms.install(...) needs to be called before you can call Send");
                return;
            }
            
            new Broadcaster<T>(payload, id);
            //broadcasters.Add(id, new Broadcaster<T>(payload, id));

            /* Broadcaster<T> broadcaster = getBroadcaster<T>(id);
            if (broadcaster == null){
                broadcasters.Add(id, new Broadcaster<T>(payload, id));
            } else {
                broadcaster.Send(payload);
            }*/
        }

        public static void On<T>(string id, Action<T> callback) {
            if (JsComms.communication == null) {
                trace("JsComms.install(...) needs to be called before you can call .On");
                return;
            }
            new Subscriber<T>(callback, id);
            //subscribers.Add(id, new Subscriber<T>(callback, id));
        }

        public static void Close()
        {
            JsComms.communication.Close();
        }

        /* private static Broadcaster<T> getBroadcaster<T>(string id)
        {
            dynamic broadcaster = null;
            broadcasters.TryGetValue(id, out broadcaster);
            if (broadcaster != null){
                Broadcaster<T> broadcaster2 = (Broadcaster<T>)broadcaster;
                return broadcaster2;
            }
            return null;
        }*/
	}

    class Broadcaster<T> {
        Notifier<T> notifier;
        string id;

        public Broadcaster(T payload, string id) {
            this.id = id;
            Send(payload);
        }

        public Broadcaster(Notifier<T> notifier, string id) {
            this.id = id;
            this.notifier = notifier;

            notifier.Add(Send);
        }

        public void Send(T value) {
            
            //string payloadStr = Newtonsoft.Json.JsonConvert.SerializeObject(value);
            //string payloadStr = JsonConvert.SerializeObject(value);
            //string payloadStr = JsonUtility.ToJson(new P2PPayload<T>(value));
            //string payloadStr = JsonMapper.ToJson(value);
            
            CommsPayload<T> payload = new CommsPayload<T>(value);
            CommsMessage message = new CommsMessage(JsonUtility.ToJson(payload), id);
            string messageStr = JsonUtility.ToJson(message);
            JsComms.communication.Send(id, messageStr);
        }
    }

    class Subscriber<T> {
        Notifier<T> notifier;
        Action<T> callback;
        string id;

        public Subscriber(Action<T> callback, string id) {
            this.callback = callback;
            this.id = id;

            JsComms.communication.AddListener(id, onMessage);
        }

        public Subscriber(Notifier<T> notifier, string id) {
            this.notifier = notifier;

            JsComms.communication.AddListener(id, onMessage);
        }

        void onMessage(string strMessage)
        {
            try {
                /*
                //Debug.Log("payload = " + message.payload);
                P2PPayload<T> payload = JsonUtility.FromJson<P2PPayload<T>>(message.payload);
                //P2PPayload<T> payload = JsonMapper.ToObject<P2PPayload<T>>(message.payload);
                T v = payload.value;
                 */


                //CommsMessage<T> message = null;
                CommsPayload<T> transfer = null;
                try {
                    //message = (CommsMessage<T>)JsonUtility.FromJson(strMessage, P2PMessageType);
                    transfer = JsonUtility.FromJson<CommsPayload<T>>(strMessage);
                    //message = transfer.value;
                } catch (Exception ex){
                    Debug.Log("Exception: " + ex);
                    return;
                }
                
                T v = transfer.value;

                if (notifier != null){
                    notifier.Value = v;
                }
                if (callback != null){
                    callback(v);
                }
                
            } catch (Exception ex){
                Debug.Log("Exception: " + ex.ToString());
            }
        }

        public static dynamic Cast(dynamic obj, Type castTo)
        {
            return Convert.ChangeType(obj, castTo);
        }
    }

    /*
    // JS to Unity
    [Serializable]
    public class TransferPayload<T>
    {
        public T value;
        
        public TransferPayload(T value)
        {
            this.value = value;
        }
    }
     */
}

