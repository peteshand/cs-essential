using UnityEngine;
using System.Text;
using System.Collections;
using System.Net.Sockets;
using System.Net;
/*
namespace p2p
{
    public class Communication : MonoBehaviour
    {
    
        [SerializeField]
        int UdpPort = 33333;
        [SerializeField]
        string host = "127.0.0.1";
        [SerializeField]
        UTF8Encoding encoding = new UTF8Encoding ();
        [SerializeField]
        WaitForSeconds UdpDelay = new WaitForSeconds (.3f);
        [SerializeField]
        IPEndPoint UdpEndPoint = null;
        [SerializeField]
        UdpClient client = null;

        [System.Serializable]
        public class JsonObject : System.Object {
            public string[] values;

            public JsonObject (string[] array) {
                values = array;
            }
        }

        public void UdpConnect () {
            client = new UdpClient ();
        }

        public void UdpDisconnect () {
            client.Close ();
        }

        void UdpReceive(byte[] data){
            string JsonString = encoding.GetString (data);
            Debug.Log("JsonString = " + JsonString);
            //JsonObject Json = JsonUtility.FromJson <JsonObject> (JsonString);
        }

        public IEnumerator UdpCoro() {
            byte[] data = null;
            while (true){
                if (client.Available > 0) {
                    yield return null;
                    data = client.Receive (ref UdpEndPoint);
                    UdpReceive (data);
                    data = null;
                }
                yield return UdpDelay;
            }
        }

        public void UdpSend (P2PMessage message){
            JsonObject Json = new JsonObject (values);
            string Jsonstring = JsonUtility.ToJson (Json);
            byte[] data = encoding.GetBytes (Jsonstring);
            Debug.Log("Send: " + host + ":" + UdpPort);
            client.Send (data, data.Length, host, UdpPort);
        }

        void Start (){
            Debug.Log("Start");

            
            UdpConnect ();

            string payload = JsonUtility.ToJson(new P2PPayload<T>(v));
            gameServer.Send(new P2PMessage(payload, id));
            UdpSend ("Test");
        }
    }
}
 */