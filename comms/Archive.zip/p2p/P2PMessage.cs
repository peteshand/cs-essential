using System;

namespace p2p
{
	[Serializable]
    public class P2PMessage
    {
        public string payload;
        public string id;
        
        public P2PMessage(string payload, string id)
        {
            this.payload = payload;
            this.id = id;
        }
    }
}

