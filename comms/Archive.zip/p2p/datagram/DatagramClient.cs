using System.Net.Sockets;
using System.Text;
using UnityEngine;

namespace p2p.datagram
{
    public class DatagramClient : MonoBehaviour
    {
        int port = 33333;
        string host = "127.0.0.1";
        //var buffer:Buffer;
        //var client:Socket;
        [SerializeField]
        UdpClient client = null;
        [SerializeField]
        UTF8Encoding encoding = new UTF8Encoding ();
        
        public DatagramClient() {
            
            
        }

        public void Init(string host, int port) {
            this.host = host;
            this.port = port;

            client = new UdpClient ();
        }

        public void Send(P2PMessage message) {
            string Jsonstring = JsonUtility.ToJson(message);
            byte[] data = encoding.GetBytes (Jsonstring);
            Debug.Log("Send: " + host + ":" + port);
            client.Send (data, data.Length, host, port);
        }

        public void Close()
        {
            client.Close();
        }




        /* 
        [SerializeField]
        int UdpPort = 33333;
        [SerializeField]
        string host = "127.0.0.1";
        
        [SerializeField]
        WaitForSeconds UdpDelay = new WaitForSeconds (.3f);
        [SerializeField]
        IPEndPoint UdpEndPoint = null;
        

        [System.Serializable]
        public class JsonObject : System.Object {
            public string[] values;

            public JsonObject (string[] array) {
                values = array;
            }
        }

        public void UdpConnect () {
            
        }

        public void UdpDisconnect () {
            client.Close ();
        }

        void UdpReceive(byte[] data){
            string JsonString = encoding.GetString (data);
            Debug.Log("JsonString = " + JsonString);
            //JsonObject Json = JsonUtility.FromJson <JsonObject> (JsonString);
        }

        public IEnumerator UdpCoro() {
            byte[] data = null;
            while (true){
                if (client.Available > 0) {
                    yield return null;
                    data = client.Receive (ref UdpEndPoint);
                    UdpReceive (data);
                    data = null;
                }
                yield return UdpDelay;
            }
        }

        */
    }
}