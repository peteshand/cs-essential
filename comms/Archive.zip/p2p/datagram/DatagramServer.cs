using System;
using System.Collections;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using time;
using UnityEngine;

namespace p2p.datagram
{
    public class DatagramServer : MonoBehaviour
    {
        //Socket server;
	    Dictionary<string, Action<P2PMessage>> callbacks = new Dictionary<string, Action<P2PMessage>>();

        [SerializeField]
        UdpClient client = null;
        [SerializeField]
        UTF8Encoding encoding = new UTF8Encoding ();
        [SerializeField]
        IPEndPoint UdpEndPoint = null;
        [SerializeField]
        WaitForSeconds UdpDelay = new WaitForSeconds (.3f);

        string host;
        int port;
        Action<bool> callback;

        public DatagramServer() {
            
            
        }

        public void Init(string host, int port, Action<bool> callback)
        {
            this.host = host;
            this.port = port;
            this.callback = callback;
            callback(true);

            Debug.Log("DatagramSubscriber START");
            
            client = new UdpClient(port);
            
            /* try{
                client.Connect(host, port);
            }
            catch (Exception e ) {
                Debug.Log("ERROR: " + e.ToString());
            }*/
            EnterFrame.Add(Tick);

            
            Debug.Log("DatagramSubscriber END");
        }

        void Tick()
        {
            //Debug.Log(client.Available);
            if (client.Available == 0) return;

            //Creates an IPEndPoint to record the IP Address and port number of the sender. 
            // The IPEndPoint will allow you to read datagrams sent from any source.
            IPEndPoint RemoteIpEndPoint = new IPEndPoint(IPAddress.Any, port);
            try{

                // Blocks until a message returns on this socket from a remote host.
                Byte[] receiveBytes = client.Receive(ref RemoteIpEndPoint); 

                string returnData = Encoding.ASCII.GetString(receiveBytes);
            
                Debug.Log("This is the message you received " +
                                            returnData.ToString());
                Debug.Log("This message was sent from " +
                                            RemoteIpEndPoint.Address.ToString() +
                                            " on their port number " +
                                            RemoteIpEndPoint.Port.ToString());
            }
            catch ( Exception e ){
                Console.WriteLine(e.ToString()); 
            }

            //
            //byte[] data = client.Receive(ref UdpEndPoint);
            
        }

        IEnumerator UdpCoro() {
            Debug.Log("UdpCoro");
            byte[] data = null;
            while (true){
                if (client.Available > 0) {
                    yield return null;
                    data = client.Receive (ref UdpEndPoint);
                    UdpReceive (data);
                    data = null;
                }
                yield return UdpDelay;
            }
        }

        void UdpReceive(byte[] data){
            string JsonString = encoding.GetString (data);
            Debug.Log("JsonString = " + JsonString);
            //JsonObject Json = JsonUtility.FromJson <JsonObject> (JsonString);
        }

        public void AddListener(string id, Action<P2PMessage> callback) {
            callbacks.Add(id, callback);
        }

        public void Close()
        {
            client.Close();
        }
    }
}