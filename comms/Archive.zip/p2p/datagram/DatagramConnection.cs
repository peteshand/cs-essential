using UnityEngine;
using p2p;
using p2p.datagram;
using System;
using System.Net.Sockets;
using System.Net;
using System.Text;
using time;
using System.Collections.Generic;

namespace p2p.datagram
{
    public class DatagramConnection : MonoBehaviour
    {
        int port = 33333;
		string host = "127.0.0.1";
		Action<bool> callback;
		//var buffer:Buffer;
		//var socket:Socket;
		//var callbacks = new Map<String, (message:P2PMessage) -> Void>();
		[SerializeField]
        UdpClient client = null;
        [SerializeField]
        UTF8Encoding encoding = new UTF8Encoding ();
		
		Dictionary<string, Action<P2PMessage>> callbacks = new Dictionary<string, Action<P2PMessage>>();

        [SerializeField]
        IPEndPoint UdpEndPoint = null;
        [SerializeField]
        WaitForSeconds UdpDelay = new WaitForSeconds (.3f);
		
		public DatagramConnection()
		{
			
		}

		public void Client(string host, int port, Action<bool> callback = null) {
			this.host = host;
			this.port = port;
			this.callback = callback;

			client = new UdpClient();

			//socket.on('message', onMessage);
			//socket.on('error', onError);
			//socket.on('listening', onListening);
			addListeners();

			//try{
                //client.Connect(host, port);
				EnterFrame.Add(Tick);
            //}
            //catch (Exception e ) {
            //    Debug.Log("ERROR: " + e.ToString());
            //}
			
		}

		public void Server(string host, int port, Action<bool> callback = null) {

			this.host = host;
			this.port = port;
			this.callback = callback;

			client = new UdpClient();

			//socket.on('message', onMessage);
			//socket.on('error', onError);
			//socket.on('listening', onListening);
			addListeners();

			try{
                client.Connect(host, port);
				//client.
				if (callback != null) callback(true);
				EnterFrame.Add(Tick);
            }
            catch (Exception e ) {
                Debug.Log("ERROR: " + e.ToString());
				if (callback != null) callback(false);
            }
		}

		void addListeners()
		{
			//socket.on('message', onMessage);
			//socket.on('error', onError);
			//socket.on('listening', onListening);
		}

		void Tick()
        {
            //Debug.Log(client.Available);
            if (client.Available == 0) return;

            //Creates an IPEndPoint to record the IP Address and port number of the sender. 
            // The IPEndPoint will allow you to read datagrams sent from any source.
            IPEndPoint RemoteIpEndPoint = new IPEndPoint(IPAddress.Any, port);
            try{

                // Blocks until a message returns on this socket from a remote host.
                Byte[] receiveBytes = client.Receive(ref RemoteIpEndPoint); 

                string returnData = Encoding.ASCII.GetString(receiveBytes);
            
                Debug.Log("This is the message you received " +
                                            returnData.ToString());
                Debug.Log("This message was sent from " +
                                            RemoteIpEndPoint.Address.ToString() +
                                            " on their port number " +
                                            RemoteIpEndPoint.Port.ToString());
            }
			catch (SocketException e)
			{
				Debug.Log(e);
			}
            catch ( Exception e ){
                Debug.Log(e.ToString()); 
            }
        }

		public void AddListener(string id, Action<P2PMessage> callback) {
            callbacks.Add(id, callback);
        }

		public void Send(P2PMessage message) {
            string Jsonstring = JsonUtility.ToJson(message);
            byte[] data = encoding.GetBytes (Jsonstring);
            Debug.Log("Send: " + host + ":" + port);
            client.Send (data, data.Length, host, port);
        }

        public void Close()
        {
            client.Close();
        }
    }
}