using System;

namespace p2p
{
    [Serializable]
    public class P2PPayload<T>
    {
        public T value;
        
        public P2PPayload(T value)
        {
            this.value = value;
        }
    }
}

