namespace p2p
{
	public class Ids
	{
        public static string PEER_CONNECTION_REQUEST = "PeerConnectionRequest";
        public static string PEER_CONNECTION_RESPONSE = "PeerConnectionResponse";
    }
}